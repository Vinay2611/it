create trigger streams_before_ins_tr
  before INSERT
  on streams
  for each row
  BEGIN

END;

