create trigger AddLeave
  after INSERT
  on users
  for each row
  INSERT INTO hr_leave_status (SL,PL,CL,users_employee_id,users_id) VALUES ('0','0','0',NEW.users_employee_id,NEW.users_id);

